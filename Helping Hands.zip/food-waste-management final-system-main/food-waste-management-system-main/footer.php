<?php



echo '<div id="upper" class="col-12">
        <div style="padding: 40px 70px 40px 70px; color: white;overflow: auto;">
            <div class="col-3" style="float: left; height: 250px; padding: 10px 40px 10px 20px; font-size: 15px; color: rgb(171, 175, 181);overflow: hidden;text-overflow: ellipsis;">
                <h5>ABOUT US</h5><p>Students from ABV-IIITM GWALIOR</p>
            </div>

            <div class="col-3" style="float: right; height: 250px; padding: 10px;overflow: hidden;text-overflow: ellipsis;">
                <h5>SOCIAL ICONS</h5><p><a href="#" class="fa fa-facebook"></a><a href="#" class="fa fa-twitter"></a><a href="#" class="fa fa-google"></a><a href="#" class="fa fa-youtube"></a><a href="#" class="fa fa-instagram"></a></p>
            </div>

            <div class="col-3" style="float: right; height: 250px; padding: 10px;overflow: hidden;text-overflow: ellipsis;">
                <h5>HELP</h5> <a style="text-decoration:none" href="register.php"><button style="background-color:lightgrey;padding:5px">Donate Blood</button></a>
            </div>


            <div class="col-3" style="float: right; height: 250px; padding: 10px; font-size: 15px; color: rgb(171, 175, 181);overflow: hidden;text-overflow: ellipsis;">
                <h5>KEEP IN TOUCH</h5><p>IIITM, GWALIOR<br><br>(+91) 7898378532 &ensp; deepakkumrawat8@gmail.com</p>
            </div>
        </div>
    </div>
    <div id="lower" class="col-12">
        2018 All Rights Reserved.
    </div>'

    ?>