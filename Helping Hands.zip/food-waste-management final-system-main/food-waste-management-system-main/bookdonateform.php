<?php
include("login.php"); 
if($_SESSION['name']==''){
	header("location: signin.php");
}

$emailid= $_SESSION['email'];
$connection=mysqli_connect("localhost","root","");
$db=mysqli_select_db($connection,'demo');
if(isset($_POST['submit']))
{
    $bookname=mysqli_real_escape_string($connection, $_POST['bookname']);
    $standard=mysqli_real_escape_string($connection, $_POST['standard']);
    $quantity=mysqli_real_escape_string($connection, $_POST['quantity']);
    $phoneno=mysqli_real_escape_string($connection, $_POST['phoneno']);
    $district=mysqli_real_escape_string($connection, $_POST['district']);
    $address=mysqli_real_escape_string($connection, $_POST['address']);
    $name=mysqli_real_escape_string($connection, $_POST['name']);

    $query="insert into book_donations(email,bookname,standard,quantity,phoneno,location,address,name) values('$emailid','$bookname','$standard','$quantity','$phoneno','$district','$address','$name')";
    $query_run= mysqli_query($connection, $query);
    if($query_run)
    {
        echo '<script type="text/javascript">alert("Data saved")</script>';
        header("location:delivery.html");
    }
    else{
        echo '<script type="text/javascript">alert("Data not saved")</script>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Donate</title>
    <link rel="stylesheet" href="loginstyle.css">
</head>
<body style="background-color: #06C167;">
    <div class="container">
        <div class="regformf">
            <form action="" method="post">
                <p class="logo">Book <b style="color: #06C167; ">Donate</b></p>
                
                <div class="input">
                    <label for="bookname">Book Name:</label>
                    <input type="text" id="bookname" name="bookname" required/>
                </div>
                
                <div class="input">
                    <label for="standard">Standard:</label>
                    <input type="text" id="standard" name="standard" required/>
                </div>
                
                <div class="input">
                    <label for="quantity">Quantity:</label>
                    <input type="number" id="quantity" name="quantity" min="1" required/>
                </div>

                <b><p style="text-align: center;">Contact Details</p></b>
                <div class="input">
                    <div>
                        <label for="name">Name:</label>
                        <input type="text" id="name" name="name" value="<?php echo $_SESSION['name']; ?>" required/>
                    </div>
                    <div>
                        <label for="phoneno">Phone No:</label>
                        <input type="text" id="phoneno" name="phoneno" maxlength="10" pattern="[0-9]{10}" required/>
                    </div>
                </div>
                
                <div class="input">
                    <label for="district">District:</label>
                    <select id="district" name="district" style="padding:10px;">
                    <option value="chennai">Adilabad</option>
  <option value="kancheepuram">Bhadradri Kothegudem</option>
  <option value="thiruvallur">Hanumakonda</option>
  <option value="vellore">Hyderabad</option>
  <option value="tiruvannamalai">Jagtial</option>
  <option value="tiruvallur">Karimnagar</option>
  <option value="tiruppur">Khammam</option>
  <option value="coimbatore">Mahabubabad</option>
  <option value="erode">Mancherial</option>
  <option value="salem">Medak</option>
  <option value="namakkal">Nalgonda</option>
  <option value="tiruchirappalli">Nizamabad</option>
  <option value="thanjavur">Rangareddy</option>
  <option value="pudukkottai">Sangareddy</option>
  <option value="karur">Siddipet</option>
  <option value="ariyalur">Vikarabad</option>
  <option value="perambalur">Suryapet</option>
  <option value="madurai" selected>Warangal</option>
  <option value="virudhunagar">Yadadri Bhuvanagiri</option>
  <option value="dindigul">Peddapalli</option>
  <option value="ramanathapuram">Narayanpet</option>
  <option value="sivaganga">Mulug</option>
  <option value="thoothukkudi">Medchal</option>
  <option value="tirunelveli">Kamareddy</option>
  <option value="tiruppur">Jogulamba Gadwal</option>
  <option value="tenkasi">Bhoopalpally</option>
  <option value="kanniyakumari">Jangoan</option>
                    </select> 
                </div>

                <div class="input">
                    <label for="address">Address:</label>
                    <input type="text" id="address" name="address" required/><br>
                </div>
                
                <div class="btn">
                    <button type="submit" name="submit">Submit</button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
