<?php
ob_start();
include("connect.php");
if ($_SESSION['name'] == '') {
    header("location:signin.php");
}

if(isset($_POST['submit'])) {
    $campaign_name = $_POST['campaign_name'];
    $campaign_description = $_POST['campaign_description'];
    $amount_needed = $_POST['amount_needed'];

    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["campaign_image"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

    // Check if image file is a actual image or fake image
    $check = getimagesize($_FILES["campaign_image"]["tmp_name"]);
    if($check === false) {
        echo "File is not an image.";
        $uploadOk = 0;
    }

    // Check file size
    if ($_FILES["campaign_image"]["size"] > 500000) {
        echo "Sorry, your file is too large.";
        $uploadOk = 0;
    }

    // Allow certain file formats
    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
    && $imageFileType != "gif" ) {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
    }

    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 1 && move_uploaded_file($_FILES["campaign_image"]["tmp_name"], $target_file)) {
        // Insert into database
        $query = "INSERT INTO campaigns (campaign_name, campaign_image, campaign_description, amount_needed) 
                  VALUES ('$campaign_name', '$target_file', '$campaign_description', '$amount_needed')";
        $result = mysqli_query($connection, $query);
        if($result) {
            echo "Campaign added successfully.";
        } else {
            echo "Error adding campaign: " . mysqli_error($connection);
        }
    } elseif ($uploadOk == 0) {
        echo "Sorry, your file was not uploaded.";
    }
}

if(isset($_POST['delete'])) {
    $id = $_POST['campaign_id'];
    $query = "DELETE FROM campaigns WHERE id = $id";
    $result = mysqli_query($connection, $query);
    if ($result) {
        echo "Campaign deleted successfully.";
    } else {
        echo "Error deleting campaign: " . mysqli_error($connection);
    }
}
if(isset($_POST['modify'])) {
    $id = $_POST['campaign_id'];
    // Retrieve campaign details
    $query = "SELECT * FROM campaigns WHERE id = $id";
    $result = mysqli_query($connection, $query);
    $campaign = mysqli_fetch_assoc($result);
    // Display a form for modifying the campaign
    echo "<h1>Modify Campaign</h1>";
    echo "<form action='' method='POST' enctype='multipart/form-data'>";
    echo "<input type='hidden' name='campaign_id' value='" . $campaign['id'] . "'>";
    echo "<div class='input-group'>";
    echo "<label for='campaign_name'>Campaign Name:</label>";
    echo "<input type='text' id='campaign_name' name='campaign_name' value='" . $campaign['campaign_name'] . "' required>";
    echo "</div>";
    echo "<div class='input-group'>";
    echo "<label for='campaign_image'>Upload Image:</label>";
    echo "<input type='file' id='campaign_image' name='campaign_image' accept='image/*' required>";
    echo "</div>";
    echo "<div class='input-group'>";
    echo "<label for='campaign_description'>Description:</label>";
    echo "<textarea id='campaign_description' name='campaign_description' required>" . $campaign['campaign_description'] . "</textarea>";
    echo "</div>";
    echo "<div class='input-group'>";
    echo "<label for='amount_needed'>Amount Needed:</label>";
    echo "<input type='number' id='amount_needed' name='amount_needed' value='" . $campaign['amount_needed'] . "' required>";
    echo "</div>";
    echo "<div class='input-group'>";
    echo "<button type='submit' name='update'>Update Campaign</button>";
    echo "</div>";
    echo "</form>";

    // Add the form for viewing funds raised
    echo "<form method='POST' action='fundraise.php'>";
    echo "<input type='hidden' name='campaign_id' value='" . $campaign['id'] . "'>";
    echo "<button type='submit' name='view_funds'>View Funds Raised</button>";
    echo "</form>";
}

if(isset($_POST['update'])) {
    $id = $_POST['campaign_id'];
    $campaign_name = $_POST['campaign_name'];
    $campaign_description = $_POST['campaign_description'];
    $amount_needed = $_POST['amount_needed'];

    // Check if a new image is uploaded
    if(isset($_FILES["campaign_image"]) && $_FILES["campaign_image"]["error"] == 0) {
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($_FILES["campaign_image"]["name"]);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

        // Check file size
        if ($_FILES["campaign_image"]["size"] > 500000) {
            echo "Sorry, your file is too large.";
            $uploadOk = 0;
        }

        // Allow certain file formats
        if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
        && $imageFileType != "gif" ) {
            echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
            $uploadOk = 0;
        }

        // Check if $uploadOk is set to 0 by an error
        if ($uploadOk == 1 && move_uploaded_file($_FILES["campaign_image"]["tmp_name"], $target_file)) {
            // Update image path in database
            $query = "UPDATE campaigns SET campaign_image='$target_file' WHERE id = $id";
            $result = mysqli_query($connection, $query);
            if(!$result) {
                echo "Error updating campaign image: " . mysqli_error($connection);
            }
        } elseif ($uploadOk == 0) {
            echo "Sorry, your file was not uploaded.";
        }
    }

    // Update other campaign details
    $query = "UPDATE campaigns SET campaign_name='$campaign_name', campaign_description='$campaign_description', amount_needed='$amount_needed' WHERE id = $id";
    $result = mysqli_query($connection, $query);
    if($result) {
        echo "Campaign updated successfully.";
    } else {
        echo "Error updating campaign: " . mysqli_error($connection);
    }
}

$query = "SELECT * FROM campaigns";
$result = mysqli_query($connection, $query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <style>
         body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        nav {
            background-color: #333;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
        }
        .logo-name {
            display: flex;
            align-items: center;
        }
        .logo_name {
            font-weight: bold;
            margin-left: 10px;
        }
        .menu-items {
            display: flex;
            align-items: center;
        }
        .nav-links {
            list-style-type: none;
            margin: 0;
            padding: 0;
            display: flex;
        }
        .nav-links li {
            margin-right: 20px;
        }
        .nav-links li a {
            color: white;
            text-decoration: none;
            font-size: 16px;
        }
        .dashboard {
            padding: 20px;
        }
        .top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .campaign-form {
            background-color: white;
            padding: 20px;
            border-radius: 5px;
        }
        .campaign-form h1 {
            margin-bottom: 20px;
            font-size: 24px;
            color: #333;
        }
        .input-group {
            margin-bottom: 15px;
        }
        .input-group label {
            color: green;
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
        }
        .input-group input[type="text"],
        .input-group input[type="number"],
        .input-group textarea {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }
        .input-group input[type="file"] {
            width: auto;
            padding: 6px;
        }
        .input-group button {
            padding: 8px 15px;
            background-color: #333;
            color: white;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        img {
            max-width: 100px;
            height: auto;
        }
        .button-group {
            display: flex;
            gap: 5px;
        }

        /* Your CSS styles here */
    </style>
    <title>Campaigns</title>
</head>
<body>
    <!-- Navigation and other HTML code -->

    <section class="dashboard">
        <div class="top">
            <i class="uil uil-bars sidebar-toggle"></i>
            <p class="logo">Campaigns</p>
        </div>
        <nav>
    <div class="logo-name">
        <!-- <a href="admin.php" class="back-button" >&#8592; Back</a> -->
        <button class="btn-primary" onclick="window.location.href='admin.php'">Back</button>
        <p class="logo_name">Campaigns</p>
    </div>
    <div class="menu-items">
        <ul class="nav-links">
            <!-- Other menu items -->
        </ul>
    </div>
</nav>
        <div class="campaign-form">
            <h1>Add New Campaign</h1>
            <form action="" method="POST" enctype="multipart/form-data">
                <div class="input-group">
                    <label for="campaign_name">Campaign Name:</label>
                    <input type="text" id="campaign_name" name="campaign_name" required>
                </div>
                <div class="input-group">
                    <label for="campaign_image">Upload Image:</label>
                    <input type="file" id="campaign_image" name="campaign_image" accept="image/*" required>
                </div>
                <div class="input-group">
                    <label for="campaign_description">Description:</label>
                    <textarea id="campaign_description" name="campaign_description" required></textarea>
                </div>
                <div class="input-group">
                    <label for="amount_needed">Amount Needed:</label>
                    <input type="number" id="amount_needed" name="amount_needed" required>
                </div>
                <div class="input-group">
                    <button type="submit" name="submit">Add Campaign</button>
                </div>
            </form>
        </div>

        <!-- Display added campaigns in a table -->
        <table>
            <thead>
                <tr>
                    <th>Campaign Name</th>
                    <th>Campaign Image</th>
                    <th>Description</th>
                    <th>Amount Needed</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php
            // $query = "SELECT * FROM campaigns";
            // $result = mysqli_query($connection, $query);
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>" . $row['campaign_name'] . "</td>";
                    echo "<td><img src='" . $row['campaign_image'] . "' alt='Campaign Image'></td>";
                    echo "<td>" . $row['campaign_description'] . "</td>";
                    echo "<td>$" . $row['amount_needed'] . "</td>";
                    echo "<td>";
                    echo "<form method='POST'>";
                    echo "<input type='hidden' name='campaign_id' value='" . $row['id'] . "'>";
                    echo "<button type='submit' name='delete'>Delete</button>";
                    echo "</form>";
                    echo "<form method='POST'>";
                    echo "<input type='hidden' name='campaign_id' value='" . $row['id'] . "'>";
                    echo "<button type='submit' name='modify'>Modify</button>";
                    echo "</form>";
                    echo "<form method='POST' action='fundraise.php'>";
                    echo "<input type='hidden' name='campaign_id' value='" . $row['id'] . "'>";
                    echo "<button type='submit' name='view_funds'>View Funds Raised</button>";
                    echo "</form>";
                    // echo "<form method='POST' action='DeliveryAddress.php'>";
                    // echo "<input type='hidden' name='campaign_id' value='" . $row['id'] . "'>";
                    // echo "<button type='submit' name='Delivery Address'>Delivery Address</button>";
                    // echo "</form>";
                    echo "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='5'>No campaigns found.</td></tr>";
            }
            ?>
            </tbody>
        </table>
    </section>

    <script src="admin.js"></script>
</body>

</html>
<?php
ob_end_flush();
?>
