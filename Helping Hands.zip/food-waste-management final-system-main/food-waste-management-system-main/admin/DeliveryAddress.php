<?php
include("connect.php");

// Delete address if delete button is clicked
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $query = "DELETE FROM D_address WHERE id = $id";
    $result = mysqli_query($connection, $query);
    // No need for alert message
}

// Add new address if form is submitted
if (isset($_POST['submit'])) {
    $address = $_POST['address'];
    $city = $_POST['city'];
    $pincode = $_POST['pincode'];

    $query = "INSERT INTO D_address (address, city, pincode) VALUES ('$address', '$city', '$pincode')";
    $result = mysqli_query($connection, $query);

    if ($result) {
        // No need for alert message
    } else {
        // No need for alert message
    }
}

$query = "SELECT * FROM D_address";
$result = mysqli_query($connection, $query);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Delivery Address</title>
    <style>
        /* Your CSS styles here */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            /* background-color: #042743; */
        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"],
        textarea {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 3px;
            margin-bottom: 10px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #333;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 3px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #555;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            border: 1px solid #ccc;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        .delete-button {
            background-color: #f00;
            color: #fff;
            border: none;
            padding: 5px 10px;
            border-radius: 3px;
            cursor: pointer;
        }
    </style>
</head>

<body >
    <div class="container" >
        <!-- <a href="admin.php" style="position: absolute; top: 20px; left: 20px;">Back</a> -->
        <button class="btn-primay" style="position: absolute; top: 20px; left: 20px;" onclick="window.location.href='admin.php'">Back</button>
        <h1>Add Delivery Address</h1>
        <form action="" method="POST">
            <label for="address">Address:</label><br>
            <textarea id="address" name="address" rows="4" cols="50" required></textarea><br><br>
            <label for="city">City:</label><br>
            <input type="text" id="city" name="city" required><br><br>
            <label for="pincode">Pincode:</label><br>
            <input type="text" id="pincode" name="pincode" required><br><br>
            <input type="submit" name="submit" value="Submit">
        </form>

        <h2>Delivery Address</h2>
        <table>
            <thead>
                <tr>
                    <th>Address</th>
                    <th>City</th>
                    <th>Pincode</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>{$row['address']}</td>";
                    echo "<td>{$row['city']}</td>";
                    echo "<td>{$row['pincode']}</td>";
                    echo "<td><a href='?delete={$row['id']}' class='delete-button'>Delete</a></td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>

</html>

<?php
mysqli_close($connection);
?>