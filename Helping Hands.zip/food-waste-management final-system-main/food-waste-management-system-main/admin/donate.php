<?php
// Start session
session_start();

// Include database connection
include "../connection.php";
include("connect.php"); 

// Redirect if user is not logged in
if(empty($_SESSION['name'])){
    header("location:signin.php");
    exit; // Exit to prevent further execution
}

// Database connection
$connection=mysqli_connect("localhost:3306","root","");
$db=mysqli_select_db($connection,'demo');

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
    <!----======== CSS ======== -->
    <link rel="stylesheet" href="admin.css">
     
    <!----===== Iconscout CSS ===== -->
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <style>
        .nr{
            color:white;
        }
        .col{
            color:white;
        }
    </style>
    <title>Admin Dashboard Panel</title> 
</head>
<body>
    <nav>
        <div class="logo-name">
            <div class="logo-image">
                <!--<img src="images/logo.png" alt="">-->
            </div>

            <span class="logo_name">ADMIN</span>
        </div>

        <div class="menu-items">
            <ul class="nav-links">
                <li><a href="admin.php">
                    <i class="uil uil-estate"></i>
                    <span class="link-name">Dashboard</span>
                </a></li>
                <li><a href="campaign.php">
                    <i class="uil uil-files-landscapes"></i>
                    <span class="link-name">Campaigns</span>
                </a></li>
                <li><a href="analytics.php">
                    <i class="uil uil-chart"></i>
                    <span class="link-name">Analytics</span>
                </a></li>
                <li><a href="#">
                    <i class="uil uil-heart"></i>
                    <span class="link-name">Donates</span>
                </a></li>
                <li><a href="feedback.php">
                    <i class="uil uil-comments"></i>
                    <span class="link-name">Feedbacks</span>
                </a></li>
                <li><a href="DeliveryAddress.php">
                    <i class="uil uil-files-landscapes"></i>
                    <span class="link-name">DeliveryAddress</span>
                </a></li>
            </ul>
            
            <ul class="logout-mode">
                <li><a href="../logout.php">
                    <i class="uil uil-signout"></i>
                    <span class="link-name">Logout</span>
                </a></li>

                <li class="mode">
                    <a href="#">
                        <i class="uil uil-moon"></i>
                    <span class="link-name">Dark Mode</span>
                </a>

                <div class="mode-toggle">
                  <span class="switch"></span>
                </div>
            </li>
            </ul>
        </div>
    </nav>

    <section class="dashboard" style="background-image:url(back.jpg); background-size: 100% 100%; background-repeat: no-repeat; background-attachment: fixed;">
        <div class="top">
            <i class="uil uil-bars sidebar-toggle"></i>
            <p class="logo">Helping <b style="color: #06C167;">Hands</b></p>
            <p class="user"></p>
        </div>
        <br><br><br>

        <div class="activity">
            <div class="location">
                <form method="post">
                    <label for="location" class="logo" style="color:white">Select Location:</label>
                    <select id="location" name="location">
                    <option value="chennai">Adilabad</option>
  <option value="kancheepuram">Bhadradri Kothegudem</option>
  <option value="thiruvallur">Hanumakonda</option>
  <option value="vellore">Hyderabad</option>
  <option value="tiruvannamalai">Jagtial</option>
  <option value="tiruvallur">Karimnagar</option>
  <option value="tiruppur">Khammam</option>
  <option value="coimbatore">Mahabubabad</option>
  <option value="erode">Mancherial</option>
  <option value="salem">Medak</option>
  <option value="namakkal">Nalgonda</option>
  <option value="tiruchirappalli">Nizamabad</option>
  <option value="thanjavur">Rangareddy</option>
  <option value="pudukkottai">Sangareddy</option>
  <option value="karur">Siddipet</option>
  <option value="ariyalur">Vikarabad</option>
  <option value="perambalur">Suryapet</option>
  <option value="madurai" selected>Warangal</option>
  <option value="virudhunagar">Yadadri Bhuvanagiri</option>
  <option value="dindigul">Peddapalli</option>
  <option value="ramanathapuram">Narayanpet</option>
  <option value="sivaganga">Mulug</option>
  <option value="thoothukkudi">Medchal</option>
  <option value="tirunelveli">Kamareddy</option>
  <option value="tiruppur">Jogulamba Gadwal</option>
  <option value="tenkasi">Bhoopalpally</option>
  <option value="kanniyakumari">Jangoan</option>
                    </select>
                    <input type="submit" value="Get Details">
                </form>
                <br>

                <?php
                // Get the selected location from the form
                if(isset($_POST['location'])) {
                    $location = $_POST['location'];
                    
                    // Query food donations
                    $food_sql = "SELECT * FROM food_donations WHERE location='$location'";
                    $food_result = mysqli_query($connection, $food_sql);
                    
                    // Query clothes donations
                    $clothes_sql = "SELECT * FROM clothes_donations WHERE location='$location'";
                    $clothes_result = mysqli_query($connection, $clothes_sql);
                    
                    // Display food donations
                    if ($food_result->num_rows > 0) {
                        echo "<h2 class='col'>Food Donations :</h2>";
                        echo "<div class=\"table-container\">";
                        echo "<div class=\"table-wrapper\">";
                        echo "<table class=\"table\">";
                        echo "<thead><tr><th>Name</th><th>Donation</th><th>Category</th><th>Phone Number</th><th>Date/Time</th><th>Address</th><th>Quantity</th></tr></thead><tbody>";

                        while($row = $food_result->fetch_assoc()) {
                            echo "<tr><td data-label=\"name\">" . $row['name'] . "</td><td data-label=\"food\">" . $row['food'] . "</td><td data-label=\"category\">" . $row['category'] . "</td><td data-label=\"phone\">" . $row['phoneno'] . "</td><td data-label=\"date\">" . $row['date'] . "</td><td data-label=\"address\">" . $row['address'] . "</td><td data-label=\"quantity\">" . $row['quantity'] . "</td></tr>";
                        }

                        echo "</tbody></table></div>";
                    } else {
                        echo "<p class='nr'>No food donations found.</p>";
                    }

                    // Display clothes donations
                    if ($clothes_result->num_rows > 0) {
                        echo "<h2 class='col'>Clothes Donations :</h2>";
                        echo "<div class=\"table-container\">";
                        echo "<div class=\"table-wrapper\">";
                        echo "<table class=\"table\">";
                        echo "<thead><tr><th>Name</th><th>Item</th><th>Category</th><th>Phone Number</th><th>Date/Time</th><th>Address</th><th>Quantity</th></tr></thead><tbody>";

                        while($row = $clothes_result->fetch_assoc()) {
                            echo "<tr><td data-label=\"name\">" . $row['name'] . "</td><td data-label=\"item\">" . $row['type'] . "</td><td data-label=\"category\">" . $row['quantity'] . "</td><td data-label=\"phone\">" . $row['phoneno'] . "</td><td data-label=\"date\">" . $row['date'] . "</td><td data-label=\"address\">" . $row['address'] . "</td><td data-label=\"quantity\">" . $row['quantity'] . "</td></tr>";
                        }

                        echo "</tbody></table></div>";
                    } else {
                        echo "<p class='nr'>No clothes donations found.</p>";
                    }
                }
                ?>
            </div>
        </div>
    </section>

    <script src="admin.js"></script>
</body>
</html>