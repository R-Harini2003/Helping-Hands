<?php
ob_start(); 
include("connect.php"); 
include '../connection.php';

if($_SESSION['name']==''){
	header("location:deliverylogin.php");
}
$name=$_SESSION['name'];
$city=$_SESSION['city'];

$ch=curl_init();
curl_setopt($ch,CURLOPT_URL,"http://ip-api.com/json");
curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
$result=curl_exec($ch);
$result=json_decode($result);

$id=$_SESSION['Did'];

// Fetch all recently donated food donations
$sql = "SELECT fd.Fid AS Fid, fd.location as cure, fd.name, fd.phoneno, fd.date, fd.delivery_by, fd.address as From_address, 
                ad.name AS delivery_person_name, ad.address AS To_address, fd.delivery_address
                FROM food_donations fd
                LEFT JOIN admin ad ON fd.assigned_to = ad.Aid 
                WHERE assigned_to IS NOT NULL AND delivery_by IS NULL AND fd.location='$city'
                ORDER BY fd.date DESC";

$result = mysqli_query($connection, $sql);

// Check for errors
if (!$result) {
    die("Error executing query: " . mysqli_error($connection));
}

// Fetch the food donation data as an associative array
$data_food = array();
while ($row_food = mysqli_fetch_assoc($result)) {
    $data_food[] = $row_food;
}

// If the delivery person takes an order, update the delivery_by field in the database
if (isset($_POST['food']) && isset($_POST['delivery_person_id'])) {
    $order_id = $_POST['order_id'];
    $delivery_person_id = $_POST['delivery_person_id'];
    $sql = "UPDATE food_donations SET delivery_by = $delivery_person_id WHERE Fid = $order_id";
    $result = mysqli_query($connection, $sql);

    if (!$result) {
        die("Error assigning order: " . mysqli_error($connection));
    }

    // Reload the page to prevent duplicate assignments
    header('Location: ' . $_SERVER['REQUEST_URI']);
    exit;
}

// Fetch orders assigned to the current delivery person
$sql_assigned = "SELECT fd.Fid AS Fid, fd.location as cure, fd.name, fd.phoneno, fd.date, fd.delivery_by, fd.address as From_address, 
                ad.name AS delivery_person_name, ad.address AS To_address, fd.delivery_address, fd.status
                FROM food_donations fd
                LEFT JOIN admin ad ON fd.assigned_to = ad.Aid 
                WHERE delivery_by = $id
                ORDER BY fd.date DESC";


$result_assigned = mysqli_query($connection, $sql_assigned);

// Check for errors
if (!$result_assigned) {
    die("Error executing query: " . mysqli_error($connection));
}

// Fetch the assigned orders data as an associative array
$data_assigned = array();
while ($row_assigned = mysqli_fetch_assoc($result_assigned)) {
    $data_assigned[] = $row_assigned;
}
if (isset($_POST['update_status']) && isset($_POST['status'])) {
    $order_id = $_POST['order_id'];
    $status = $_POST['status'];
    
    if ($status === 'delivered_to') {
        $delivery_address = $row_assigned['delivery_address']; // Get the selected delivery address
        $status = "Delivered to " . $delivery_address; // Update the status value
    }
    
    $sql = "UPDATE food_donations SET status = '$status' WHERE Fid = $order_id";
    $result = mysqli_query($connection, $sql);
    
    if (!$result) {
        die("Error updating status: " . mysqli_error($connection));
    }

    // Reload the page to prevent duplicate updates
    header('Location: ' . $_SERVER['REQUEST_URI']);
    exit;
}




mysqli_close($connection);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Take Food Orders</title>
    <link rel="stylesheet" href="../home.css">
    <link rel="stylesheet" href="delivery.css">
    <style>
        select[name="status"] {
            width: 100%;
            box-sizing: border-box;
        }
    </style>
</head>
<body>
<header>
<div class="logo">Helping<b style="color: #06C167;"> Hands</b></div>
    <div class="hamburger">
        <div class="line"></div>
        <div class="line"></div>
        <div class="line"></div>
    </div>
    <nav class="nav-bar">
        <ul>
            <li><a href="#home" class="active">Home</a></li>
            <li><a href="openmap.php" >Map</a></li>
            <li><a href="deliverymyord.php" >My Food Orders</a></li> 
        </ul>
    </nav>
</header>
<br>
<h2><center>Welcome <?php echo"$name";?></center></h2>

<h3>Orders Assigned to You:</h3>
<div class="table-container">
    <div class="table-wrapper">
        <table class="table">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Phone Number</th>
                    <th>Date/Time</th>
                    <th>Pickup Address</th>
                    <th>Delivery Address</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($data_assigned as $row_assigned) { ?>
    <tr>
        <td><?= $row_assigned['name'] ?></td>
        <td><?= $row_assigned['phoneno'] ?></td>
        <td><?= $row_assigned['date'] ?></td>
        <td><?= $row_assigned['From_address'] ?></td>
        <td><?= $row_assigned['delivery_address'] ?></td>
        <td>
    <form method="post" action="">
        <input type="hidden" name="order_id" value="<?= $row_assigned['Fid'] ?>">
        <select name="status">
    <option value="donation_picked" <?= ($row_assigned['status'] === 'donation_picked') ? 'selected' : '' ?>>Donation Picked</option>
    <option value="on_the_way" <?= ($row_assigned['status'] === 'on_the_way') ? 'selected' : '' ?>>On the Way</option>
    <?php
    $selected_address = ($row_assigned['status'] === 'Delivered to ' . $row_assigned['delivery_address']);
    ?>
    <option value="<?= $row_assigned['delivery_address'] ?>" <?= $selected_address ? 'selected' : '' ?>><?= $selected_address ? 'Delivered to ' . $row_assigned['delivery_address'] : 'Delivered to ' . $row_assigned['delivery_address'] ?></option>
</select>
<?php if (!$selected_address) { ?>
    <button type="submit" name="update_status">Update</button>
<?php } ?>
    </form>
</td>
    </tr>
<?php } ?>

            </tbody>
        </table>
    </div>
</div>

</body>
</html>
