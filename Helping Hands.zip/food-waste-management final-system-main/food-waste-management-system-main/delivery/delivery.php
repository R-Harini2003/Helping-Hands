<?php
ob_start(); 
include("connect.php"); 
include '../connection.php';

if($_SESSION['name']==''){
	header("location:deliverylogin.php");
}
$name=$_SESSION['name'];
$city=$_SESSION['city'];

$ch=curl_init();
curl_setopt($ch,CURLOPT_URL,"http://ip-api.com/json");
curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
$result=curl_exec($ch);
$result=json_decode($result);

$id=$_SESSION['Did'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script language="JavaScript" src="http://www.geoplugin.net/javascript.gp" type="text/javascript"></script>
    <link rel="stylesheet" href="../home.css">
    <link rel="stylesheet" href="delivery.css">
</head>
<body>
<header>
    <div class="logo">Helping<b style="color: #06C167;"> Hands</b></div>
    <div class="hamburger">
        <div class="line"></div>
        <div class="line"></div>
        <div class="line"></div>
    </div>
    <nav class="nav-bar">
        <ul>
            <li><a href="#home" class="active">Home</a></li>
            <li><a href="openmap.php" >Map</a></li>
            <li><a href="deliverymyord.php" >My Orders</a></li>
        </ul>
    </nav>
</header>
<br>
<script>
    hamburger=document.querySelector(".hamburger");
    hamburger.onclick =function(){
        navBar=document.querySelector(".nav-bar");
        navBar.classList.toggle("active");
    }
</script>

<style>
    .itm{
        background-color: white;
        display: grid;
    }
    .itm img{
        width: 400px;
        height: 400px;
        margin-left: auto;
        margin-right: auto;
    }
    p{
        text-align: center; font-size: 30PX;color: black; margin-top: 50px;
    }
    /* a{
        /* text-decoration: underline; */
    /* } */ 
    @media (max-width: 767px) {
        /* .itm{
            /* float: left; */
        } */
        .itm img{
            width: 350px;
            height: 350px;
        }
    /* } */
</style>

<h2><center>Welcome <?php echo"$name";?></center></h2>

<div class="itm" >
    <img src="../img/delivery.gif" alt="" width="400" height="400"> 
</div>

<div class="get">
    <button id="viewFoodDonations">View Food Donations</button>
    <button id="viewClothesDonations">View Clothes Donations</button>
    <!-- <button id="viewBooksDonations">View Books Donations</button> -->

</div>

<script>
    document.getElementById("viewFoodDonations").addEventListener("click", function() {
        window.location.href = "takefoodorders.php";
    });

    document.getElementById("viewClothesDonations").addEventListener("click", function() {
        window.location.href = "takeclothesorder.php";
    });
    document.getElementById("viewBooksDonations").addEventListener("click", function() {
        window.location.href = "takebooksorder.php";
    });
</script>

</body>
</html>
