<?php
session_start();

if(isset($_SESSION['name'])){
    $name = $_SESSION['name'];
} else {
    $name = ''; // Set a default value if the session variable is not set
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Orders</title>
    <link rel="stylesheet" href="../home.css">
    <link rel="stylesheet" href="delivery.css">
</head>
<body>
<header>
    <div class="logo">Helping<b style="color: #06C167;"> Hands</b></div>
    <div class="hamburger">
        <div class="line"></div>
        <div class="line"></div>
        <div class="line"></div>
    </div>
    <nav class="nav-bar">
        <ul>
            <li><a href="#home" class="active">Home</a></li>
            <li><a href="openmap.php">Map</a></li>
            <li><a href="deliverymyord.php">My Orders</a></li> 
        </ul>
    </nav>
</header>
<br>
<h2><center>Welcome <?php echo $name;?></center></h2>

<div>
    <button onclick="window.location.href='foodmyord.php'">View Assigned Food Donations</button>
    <button onclick="window.location.href='clothesmyord.php'">View Assigned Clothes Donations</button>
    <!-- <button onclick="window.location.href='booksmyord.php'">View Assigned Books Donations</button> -->
    <div class="itm">
    <img src="../img/delivery.gif" alt="" width="400" height="400"> 
</div>

</div>

</body>
</html>
