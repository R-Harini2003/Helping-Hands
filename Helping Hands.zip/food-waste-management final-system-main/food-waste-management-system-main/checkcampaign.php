<?php
include("connection.php");

$query = "SELECT * FROM campaigns";
$result = mysqli_query($connection, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Check Campaigns</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
        }
        .campaign {
            margin-bottom: 20px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .campaign img {
    width: 200px; /* Set a fixed width for the images */
    height: auto;
    margin-right: 10px;
    vertical-align: middle;
}
        .campaign .details {
            display: inline-block;
            vertical-align: middle;
        }
        .donate-button {
            display: inline-block;
            padding: 5px 10px;
            background-color: #007bff;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
        }
        .donate-button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body style="    background-color: #06C167;">
    <div class="container">
        <h1>Available Campaigns</h1>
        <?php
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<div class='campaign'>";
                // echo "<img src='annadhan.jpg " . $row['campaign_image'] . "' alt='Campaign Image'>";
                echo "<img src='" . $row['campaign_image'] . "' alt='Campaign Image'>";
                echo "<div class='details'>";
                echo "<h3>" . $row['campaign_name'] . "</h3>";
                echo "<p><strong>Description:</strong> " . $row['campaign_description'] . "</p>";
                echo "<p><strong>Amount Needed:</strong> $" . $row['amount_needed'] . "</p>";
                echo "<a href='donate.php?campaign_id=" . $row['id'] . "' class='donate-button'>Donate Now</a>";


                echo "</div>";
                echo "</div>";
            }
        } else {
            echo "<p>No campaigns available.</p>";
        }
        ?>
    </div>
</body>
</html>
