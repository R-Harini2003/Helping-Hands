<?php
include("connection.php");

$query = "SELECT account_holder, amount FROM donations_user";
$result = mysqli_query($connection, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Donors List</title>
    <style>
        body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f4f4f4;
}

.container {
    max-width: 800px;
    margin: 20px auto;
    padding: 20px;
    background-color: #fff;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

h1 {
    text-align: center;
    margin-bottom: 20px;
}

.donor {
    padding: 10px;
    border-bottom: 1px solid #ccc;
}

.donor:last-child {
    border-bottom: none;
}

.donor p {
    margin: 5px 0;
}

.donor strong {
    font-weight: bold;
}


    </style>
</head>
<body style="    background-color: #06C167;">
    <div class="container">
        <h1> Donors List</h1>
        <?php
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<div class='donor'>";
                echo "<p><strong>Name:</strong> " . $row['account_holder'] . "</p>";
                echo "<p><strong>Amount Donated:</strong> $" . $row['amount'] . "</p>";
                echo "</div>";
            }
        } else {
            echo "<p>No donors found.</p>";
        }
        ?>
    </div>
</body>
</html>
